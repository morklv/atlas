# Evaluation results

All policies use the same candidate locations, camera, scenes and mission budgets.
The fixed policy follows a predetermined lawnmower order; active selects map-based views.
Preplanned is a stronger baseline: a greedy coverage route computed for empty ground before observations.
A sensor retry consumes time. Yaw changes have zero cost in this simulator.

| Condition | Sweep coverage | Preplanned coverage | Active coverage | Gain vs preplanned (pp) | Active wins/ties/losses vs preplanned |
|---|---:|---:|---:|---:|---:|
| nominal | 74.6% | 93.9% | 94.7% | +0.81 | 6/0/4 |
| noisy | 74.4% | 94.1% | 95.2% | +1.10 | 8/1/1 |
| intermittent | 63.6% | 82.2% | 82.6% | +0.48 | 7/1/2 |

## Interpretation limits

Coverage counts cells with a sensor endpoint; unknown cells are never labeled free by default.
Accuracy is evaluated only on observed cells. Obstacle recall also counts unknown obstacles as missed.
Inspect all CSV columns: better coverage alone does not establish better classification or shorter flights.
Noise and dropout perturb depth. They do not simulate lighting, dust physics, real optics or localization drift.
These seeds are a reproducible benchmark, not evidence of real-world reliability.
Once used to adjust the algorithm, these layouts are development data; evaluate again on new seeds.
